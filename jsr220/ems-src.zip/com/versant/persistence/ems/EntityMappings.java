/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.CascadeType;
import com.versant.persistence.ems.Embeddable;
import com.versant.persistence.ems.EmbeddableSuperclass;
import com.versant.persistence.ems.Entity;
import com.versant.persistence.ems.NativeQuery;
import com.versant.persistence.ems.Query;
import com.versant.persistence.ems.SequenceGenerator;
import com.versant.persistence.ems.TableGenerator;

/**
 * Java class for entity-mappings element declaration.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <element name="entity-mappings">
 *   <complexType>
 *     <complexContent>
 *       <restriction base="xsd:anyType">
 *         <sequence>
 *           <element name="package" type="xsd:string" minOccurs="0"/>
 *           <element name="default-access" type="access-type" minOccurs="0"/>
 *           <element name="default-cascade" type="cascade-type" maxOccurs="3" minOccurs="0"/>
 *           <element name="embeddable-superclass" type="embeddable-superclass" maxOccurs="unbounded" minOccurs="0"/>
 *           <element name="entity" type="entity" maxOccurs="unbounded" minOccurs="0"/>
 *           <element name="embeddable" type="embeddable" maxOccurs="unbounded" minOccurs="0"/>
 *           <element name="query" type="query" maxOccurs="unbounded" minOccurs="0"/>
 *           <element name="native-query" type="native-query" maxOccurs="unbounded" minOccurs="0"/>
 *           <element name="sequence-generator" type="sequence-generator" maxOccurs="unbounded" minOccurs="0"/>
 *           <element name="table-generator" type="table-generator" maxOccurs="unbounded" minOccurs="0"/>
 *         </sequence>
 *       </restriction>
 *     </complexContent>
 *   </complexType>
 * </element>
 * </pre>
 * 
 */
@XmlAccessorType(javax.xml.bind.annotation.AccessType.FIELD)
@XmlType(name = "", propOrder = {
    "_package",
    "defaultAccess",
    "defaultCascade",
    "embeddableSuperclass",
    "entity",
    "embeddable",
    "query",
    "nativeQuery",
    "sequenceGenerator",
    "tableGenerator"
})
@XmlRootElement(name = "entity-mappings")
public class EntityMappings {

    @XmlElement(name = "package")
    protected String _package;

    @XmlElement(defaultValue = "PROPERTY", name = "default-access")
    protected com.versant.persistence.ems.AccessType defaultAccess;

    @XmlElement(name = "default-cascade")
    protected List<CascadeType> defaultCascade;

    @XmlElement(name = "embeddable-superclass")
    protected List<EmbeddableSuperclass> embeddableSuperclass;

    protected List<Entity> entity;
    protected List<Embeddable> embeddable;
    protected List<Query> query;

    @XmlElement(name = "native-query")
    protected List<NativeQuery> nativeQuery;

    @XmlElement(name = "sequence-generator")
    protected List<SequenceGenerator> sequenceGenerator;

    @XmlElement(name = "table-generator")
    protected List<TableGenerator> tableGenerator;

    /**
     * Gets the value of the package property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPackage() {
        return _package;
    }

    /**
     * Sets the value of the package property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPackage(String value) {
        this._package = value;
    }

    /**
     * Gets the value of the defaultAccess property.
     * 
     * @return
     *     possible object is
     *     {@link com.versant.persistence.ems.AccessType }
     *     
     */
    public com.versant.persistence.ems.AccessType getDefaultAccess() {
        return defaultAccess;
    }

    /**
     * Sets the value of the defaultAccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.versant.persistence.ems.AccessType }
     *     
     */
    public void setDefaultAccess(com.versant.persistence.ems.AccessType value) {
        this.defaultAccess = value;
    }

    protected List<CascadeType> _getDefaultCascade() {
        if (defaultCascade == null) {
            defaultCascade = new ArrayList<CascadeType>();
        }
        return defaultCascade;
    }

    /**
     * Gets the value of the defaultCascade property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the defaultCascade property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDefaultCascade().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CascadeType }
     * 
     * 
     */
    public List<CascadeType> getDefaultCascade() {
        return this._getDefaultCascade();
    }

    protected List<EmbeddableSuperclass> _getEmbeddableSuperclass() {
        if (embeddableSuperclass == null) {
            embeddableSuperclass = new ArrayList<EmbeddableSuperclass>();
        }
        return embeddableSuperclass;
    }

    /**
     * Gets the value of the embeddableSuperclass property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the embeddableSuperclass property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmbeddableSuperclass().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EmbeddableSuperclass }
     * 
     * 
     */
    public List<EmbeddableSuperclass> getEmbeddableSuperclass() {
        return this._getEmbeddableSuperclass();
    }

    protected List<Entity> _getEntity() {
        if (entity == null) {
            entity = new ArrayList<Entity>();
        }
        return entity;
    }

    /**
     * Gets the value of the entity property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the entity property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEntity().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Entity }
     * 
     * 
     */
    public List<Entity> getEntity() {
        return this._getEntity();
    }

    protected List<Embeddable> _getEmbeddable() {
        if (embeddable == null) {
            embeddable = new ArrayList<Embeddable>();
        }
        return embeddable;
    }

    /**
     * Gets the value of the embeddable property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the embeddable property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmbeddable().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Embeddable }
     * 
     * 
     */
    public List<Embeddable> getEmbeddable() {
        return this._getEmbeddable();
    }

    protected List<Query> _getQuery() {
        if (query == null) {
            query = new ArrayList<Query>();
        }
        return query;
    }

    /**
     * Gets the value of the query property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the query property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getQuery().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Query }
     * 
     * 
     */
    public List<Query> getQuery() {
        return this._getQuery();
    }

    protected List<NativeQuery> _getNativeQuery() {
        if (nativeQuery == null) {
            nativeQuery = new ArrayList<NativeQuery>();
        }
        return nativeQuery;
    }

    /**
     * Gets the value of the nativeQuery property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nativeQuery property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNativeQuery().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NativeQuery }
     * 
     * 
     */
    public List<NativeQuery> getNativeQuery() {
        return this._getNativeQuery();
    }

    protected List<SequenceGenerator> _getSequenceGenerator() {
        if (sequenceGenerator == null) {
            sequenceGenerator = new ArrayList<SequenceGenerator>();
        }
        return sequenceGenerator;
    }

    /**
     * Gets the value of the sequenceGenerator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sequenceGenerator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSequenceGenerator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SequenceGenerator }
     * 
     * 
     */
    public List<SequenceGenerator> getSequenceGenerator() {
        return this._getSequenceGenerator();
    }

    protected List<TableGenerator> _getTableGenerator() {
        if (tableGenerator == null) {
            tableGenerator = new ArrayList<TableGenerator>();
        }
        return tableGenerator;
    }

    /**
     * Gets the value of the tableGenerator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tableGenerator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTableGenerator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TableGenerator }
     * 
     * 
     */
    public List<TableGenerator> getTableGenerator() {
        return this._getTableGenerator();
    }

}
