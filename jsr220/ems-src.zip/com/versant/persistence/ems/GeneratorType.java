/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * Java class for generator-type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <simpleType name="generator-type">
 *   <restriction base="xsd:NCName">
 *     <enumeration value="TABLE"/>
 *     <enumeration value="SEQUENCE"/>
 *     <enumeration value="IDENTITY"/>
 *     <enumeration value="AUTO"/>
 *     <enumeration value="NONE"/>
 *   </restriction>
 * </simpleType>
 * </pre>
 * 
 */
@XmlEnum(String.class)
public enum GeneratorType {

    @XmlEnumValue("AUTO")
    AUTO,
    @XmlEnumValue("IDENTITY")
    IDENTITY,
    @XmlEnumValue("NONE")
    NONE,
    @XmlEnumValue("SEQUENCE")
    SEQUENCE,
    @XmlEnumValue("TABLE")
    TABLE;

}
