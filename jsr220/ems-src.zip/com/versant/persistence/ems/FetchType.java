/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * Java class for fetch-type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <simpleType name="fetch-type">
 *   <restriction base="xsd:NCName">
 *     <enumeration value="LAZY"/>
 *     <enumeration value="EAGER"/>
 *   </restriction>
 * </simpleType>
 * </pre>
 * 
 */
@XmlEnum(String.class)
public enum FetchType {

    @XmlEnumValue("EAGER")
    EAGER,
    @XmlEnumValue("LAZY")
    LAZY;

}
