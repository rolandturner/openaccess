/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import java.math.BigInteger;
import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.Table;

/**
 * Java class for table-generator complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="table-generator">
 *   <complexContent>
 *     <restriction base="xsd:anyType">
 *       <sequence>
 *         <element name="name" type="xsd:string"/>
 *         <element name="table" type="table" minOccurs="0"/>
 *         <element name="pk-column-name" type="xsd:string" minOccurs="0"/>
 *         <element name="pk-column-value" type="xsd:string" minOccurs="0"/>
 *         <element name="value-column-name" type="xsd:string" minOccurs="0"/>
 *         <element name="initial-value" type="xsd:integer" minOccurs="0"/>
 *         <element name="allocation-size" type="xsd:integer" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "table-generator")
public class TableGenerator {

    protected String name;
    protected Table table;

    @XmlElement(name = "pk-column-name")
    protected String pkColumnName;

    @XmlElement(name = "pk-column-value")
    protected String pkColumnValue;

    @XmlElement(name = "value-column-name")
    protected String valueColumnName;

    @XmlElement(defaultValue = "0", name = "initial-value")
    protected BigInteger initialValue;

    @XmlElement(defaultValue = "50", name = "allocation-size")
    protected BigInteger allocationSize;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the table property.
     * 
     * @return
     *     possible object is
     *     {@link Table }
     *     
     */
    public Table getTable() {
        return table;
    }

    /**
     * Sets the value of the table property.
     * 
     * @param value
     *     allowed object is
     *     {@link Table }
     *     
     */
    public void setTable(Table value) {
        this.table = value;
    }

    /**
     * Gets the value of the pkColumnName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPkColumnName() {
        return pkColumnName;
    }

    /**
     * Sets the value of the pkColumnName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPkColumnName(String value) {
        this.pkColumnName = value;
    }

    /**
     * Gets the value of the pkColumnValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPkColumnValue() {
        return pkColumnValue;
    }

    /**
     * Sets the value of the pkColumnValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPkColumnValue(String value) {
        this.pkColumnValue = value;
    }

    /**
     * Gets the value of the valueColumnName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValueColumnName() {
        return valueColumnName;
    }

    /**
     * Sets the value of the valueColumnName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueColumnName(String value) {
        this.valueColumnName = value;
    }

    /**
     * Gets the value of the initialValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getInitialValue() {
        return initialValue;
    }

    /**
     * Sets the value of the initialValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setInitialValue(BigInteger value) {
        this.initialValue = value;
    }

    /**
     * Gets the value of the allocationSize property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAllocationSize() {
        return allocationSize;
    }

    /**
     * Sets the value of the allocationSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAllocationSize(BigInteger value) {
        this.allocationSize = value;
    }

}
