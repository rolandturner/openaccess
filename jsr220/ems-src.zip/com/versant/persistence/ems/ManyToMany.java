/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.CascadeType;
import com.versant.persistence.ems.FetchType;
import com.versant.persistence.ems.JoinTable;

/**
 * Java class for many-to-many complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="many-to-many">
 *   <complexContent>
 *     <restriction base="xsd:anyType">
 *       <sequence>
 *         <element name="attribute" type="xsd:string"/>
 *         <element name="target-entity" type="xsd:string" minOccurs="0"/>
 *         <element name="cascade" type="cascade-type" maxOccurs="3" minOccurs="0"/>
 *         <element name="fetch" type="fetch-type" minOccurs="0"/>
 *         <element name="map-key" type="xsd:string" minOccurs="0"/>
 *         <element name="order-by" type="xsd:string" minOccurs="0"/>
 *         <choice>
 *           <element name="mapped-by" type="xsd:string" minOccurs="0"/>
 *           <element name="join-table" type="join-table" minOccurs="0"/>
 *         </choice>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "many-to-many")
public class ManyToMany {

    protected String attribute;

    @XmlElement(name = "target-entity")
    protected String targetEntity;

    protected List<CascadeType> cascade;

    @XmlElement(defaultValue = "LAZY")
    protected FetchType fetch;

    @XmlElement(name = "map-key")
    protected String mapKey;

    @XmlElement(name = "order-by")
    protected String orderBy;

    @XmlElement(name = "mapped-by")
    protected String mappedBy;

    @XmlElement(name = "join-table")
    protected JoinTable joinTable;

    /**
     * Gets the value of the attribute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttribute() {
        return attribute;
    }

    /**
     * Sets the value of the attribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttribute(String value) {
        this.attribute = value;
    }

    /**
     * Gets the value of the targetEntity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetEntity() {
        return targetEntity;
    }

    /**
     * Sets the value of the targetEntity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetEntity(String value) {
        this.targetEntity = value;
    }

    protected List<CascadeType> _getCascade() {
        if (cascade == null) {
            cascade = new ArrayList<CascadeType>();
        }
        return cascade;
    }

    /**
     * Gets the value of the cascade property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cascade property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCascade().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CascadeType }
     * 
     * 
     */
    public List<CascadeType> getCascade() {
        return this._getCascade();
    }

    /**
     * Gets the value of the fetch property.
     * 
     * @return
     *     possible object is
     *     {@link FetchType }
     *     
     */
    public FetchType getFetch() {
        return fetch;
    }

    /**
     * Sets the value of the fetch property.
     * 
     * @param value
     *     allowed object is
     *     {@link FetchType }
     *     
     */
    public void setFetch(FetchType value) {
        this.fetch = value;
    }

    /**
     * Gets the value of the mapKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMapKey() {
        return mapKey;
    }

    /**
     * Sets the value of the mapKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMapKey(String value) {
        this.mapKey = value;
    }

    /**
     * Gets the value of the orderBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderBy() {
        return orderBy;
    }

    /**
     * Sets the value of the orderBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderBy(String value) {
        this.orderBy = value;
    }

    /**
     * Gets the value of the mappedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMappedBy() {
        return mappedBy;
    }

    /**
     * Sets the value of the mappedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMappedBy(String value) {
        this.mappedBy = value;
    }

    /**
     * Gets the value of the joinTable property.
     * 
     * @return
     *     possible object is
     *     {@link JoinTable }
     *     
     */
    public JoinTable getJoinTable() {
        return joinTable;
    }

    /**
     * Sets the value of the joinTable property.
     * 
     * @param value
     *     allowed object is
     *     {@link JoinTable }
     *     
     */
    public void setJoinTable(JoinTable value) {
        this.joinTable = value;
    }

}
