/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.Basic;
import com.versant.persistence.ems.Embedded;
import com.versant.persistence.ems.Id;
import com.versant.persistence.ems.Lob;
import com.versant.persistence.ems.ManyToMany;
import com.versant.persistence.ems.ManyToOne;
import com.versant.persistence.ems.OneToMany;
import com.versant.persistence.ems.OneToOne;
import com.versant.persistence.ems.Version;

/**
 * Java class for mapping complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="mapping">
 *   <complexContent>
 *     <restriction base="xsd:anyType">
 *       <sequence>
 *         <element name="class-name" type="xsd:string"/>
 *         <element name="access" type="access-type" minOccurs="0"/>
 *         <choice>
 *           <element name="embedded-id" type="xsd:string"/>
 *           <sequence>
 *             <element name="id-class" type="xsd:string" minOccurs="0"/>
 *             <element name="id" type="id" maxOccurs="unbounded" minOccurs="0"/>
 *           </sequence>
 *         </choice>
 *         <element name="version" type="version" minOccurs="0"/>
 *         <element name="basic" type="basic" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="lob" type="lob" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="embedded" type="embedded" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="one-to-one" type="one-to-one" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="many-to-one" type="many-to-one" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="one-to-many" type="one-to-many" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="many-to-many" type="many-to-many" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="transient" type="xsd:string" maxOccurs="unbounded" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(javax.xml.bind.annotation.AccessType.FIELD)
@XmlType(name = "mapping")
public class Mapping {

    @XmlElement(name = "class-name")
    protected String className;

    @XmlElement(defaultValue = "PROPERTY")
    protected com.versant.persistence.ems.AccessType access;

    @XmlElement(name = "embedded-id")
    protected String embeddedId;

    @XmlElement(name = "id-class")
    protected String idClass;

    protected List<Id> id;
    protected Version version;
    protected List<Basic> basic;
    protected List<Lob> lob;
    protected List<Embedded> embedded;

    @XmlElement(name = "one-to-one")
    protected List<OneToOne> oneToOne;

    @XmlElement(name = "many-to-one")
    protected List<ManyToOne> manyToOne;

    @XmlElement(name = "one-to-many")
    protected List<OneToMany> oneToMany;

    @XmlElement(name = "many-to-many")
    protected List<ManyToMany> manyToMany;

    @XmlElement(name = "transient")
    protected List<String> _transient;

    /**
     * Gets the value of the className property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassName() {
        return className;
    }

    /**
     * Sets the value of the className property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassName(String value) {
        this.className = value;
    }

    /**
     * Gets the value of the access property.
     * 
     * @return
     *     possible object is
     *     {@link com.versant.persistence.ems.AccessType }
     *     
     */
    public com.versant.persistence.ems.AccessType getAccess() {
        return access;
    }

    /**
     * Sets the value of the access property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.versant.persistence.ems.AccessType }
     *     
     */
    public void setAccess(com.versant.persistence.ems.AccessType value) {
        this.access = value;
    }

    /**
     * Gets the value of the embeddedId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbeddedId() {
        return embeddedId;
    }

    /**
     * Sets the value of the embeddedId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbeddedId(String value) {
        this.embeddedId = value;
    }

    /**
     * Gets the value of the idClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdClass() {
        return idClass;
    }

    /**
     * Sets the value of the idClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdClass(String value) {
        this.idClass = value;
    }

    protected List<Id> _getId() {
        if (id == null) {
            id = new ArrayList<Id>();
        }
        return id;
    }

    /**
     * Gets the value of the id property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the id property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Id }
     * 
     * 
     */
    public List<Id> getId() {
        return this._getId();
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link Version }
     *     
     */
    public Version getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link Version }
     *     
     */
    public void setVersion(Version value) {
        this.version = value;
    }

    protected List<Basic> _getBasic() {
        if (basic == null) {
            basic = new ArrayList<Basic>();
        }
        return basic;
    }

    /**
     * Gets the value of the basic property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the basic property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBasic().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Basic }
     * 
     * 
     */
    public List<Basic> getBasic() {
        return this._getBasic();
    }

    protected List<Lob> _getLob() {
        if (lob == null) {
            lob = new ArrayList<Lob>();
        }
        return lob;
    }

    /**
     * Gets the value of the lob property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lob property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLob().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Lob }
     * 
     * 
     */
    public List<Lob> getLob() {
        return this._getLob();
    }

    protected List<Embedded> _getEmbedded() {
        if (embedded == null) {
            embedded = new ArrayList<Embedded>();
        }
        return embedded;
    }

    /**
     * Gets the value of the embedded property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the embedded property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmbedded().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Embedded }
     * 
     * 
     */
    public List<Embedded> getEmbedded() {
        return this._getEmbedded();
    }

    protected List<OneToOne> _getOneToOne() {
        if (oneToOne == null) {
            oneToOne = new ArrayList<OneToOne>();
        }
        return oneToOne;
    }

    /**
     * Gets the value of the oneToOne property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the oneToOne property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOneToOne().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OneToOne }
     * 
     * 
     */
    public List<OneToOne> getOneToOne() {
        return this._getOneToOne();
    }

    protected List<ManyToOne> _getManyToOne() {
        if (manyToOne == null) {
            manyToOne = new ArrayList<ManyToOne>();
        }
        return manyToOne;
    }

    /**
     * Gets the value of the manyToOne property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the manyToOne property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getManyToOne().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ManyToOne }
     * 
     * 
     */
    public List<ManyToOne> getManyToOne() {
        return this._getManyToOne();
    }

    protected List<OneToMany> _getOneToMany() {
        if (oneToMany == null) {
            oneToMany = new ArrayList<OneToMany>();
        }
        return oneToMany;
    }

    /**
     * Gets the value of the oneToMany property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the oneToMany property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOneToMany().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OneToMany }
     * 
     * 
     */
    public List<OneToMany> getOneToMany() {
        return this._getOneToMany();
    }

    protected List<ManyToMany> _getManyToMany() {
        if (manyToMany == null) {
            manyToMany = new ArrayList<ManyToMany>();
        }
        return manyToMany;
    }

    /**
     * Gets the value of the manyToMany property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the manyToMany property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getManyToMany().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ManyToMany }
     * 
     * 
     */
    public List<ManyToMany> getManyToMany() {
        return this._getManyToMany();
    }

    protected List<String> _getTransient() {
        if (_transient == null) {
            _transient = new ArrayList<String>();
        }
        return _transient;
    }

    /**
     * Gets the value of the transient property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transient property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransient().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getTransient() {
        return this._getTransient();
    }

}
