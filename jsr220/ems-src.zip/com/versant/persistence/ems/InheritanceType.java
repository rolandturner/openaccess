/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * Java class for inheritance-type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <simpleType name="inheritance-type">
 *   <restriction base="xsd:NCName">
 *     <enumeration value="SINGLE_TABLE"/>
 *     <enumeration value="JOINED"/>
 *     <enumeration value="TABLE_PER_CLASS"/>
 *   </restriction>
 * </simpleType>
 * </pre>
 * 
 */
@XmlEnum(String.class)
public enum InheritanceType {

    @XmlEnumValue("JOINED")
    JOINED,
    @XmlEnumValue("SINGLE_TABLE")
    SINGLE_TABLE,
    @XmlEnumValue("TABLE_PER_CLASS")
    TABLE_PER_CLASS;

}
