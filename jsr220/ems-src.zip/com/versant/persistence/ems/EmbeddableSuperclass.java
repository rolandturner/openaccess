/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.Mapping;

/**
 * Java class for embeddable-superclass complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="embeddable-superclass">
 *   <complexContent>
 *     <extension base="mapping">
 *     </extension>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "embeddable-superclass")
public class EmbeddableSuperclass
    extends Mapping
{

}
