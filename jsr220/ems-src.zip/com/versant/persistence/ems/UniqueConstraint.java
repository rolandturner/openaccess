/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Java class for unique-constraint complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="unique-constraint">
 *   <complexContent>
 *     <restriction base="xsd:anyType">
 *       <sequence>
 *         <element name="column-name" type="xsd:string" maxOccurs="unbounded"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "unique-constraint")
public class UniqueConstraint {

    @XmlElement(name = "column-name")
    protected List<String> columnName;

    protected List<String> _getColumnName() {
        if (columnName == null) {
            columnName = new ArrayList<String>();
        }
        return columnName;
    }

    /**
     * Gets the value of the columnName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the columnName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getColumnName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getColumnName() {
        return this._getColumnName();
    }

}
