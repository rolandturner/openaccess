/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.versant.persistence.ems.AttributeOverride;
import com.versant.persistence.ems.Basic;
import com.versant.persistence.ems.Column;
import com.versant.persistence.ems.DiscriminatorColumn;
import com.versant.persistence.ems.Embeddable;
import com.versant.persistence.ems.EmbeddableSuperclass;
import com.versant.persistence.ems.Embedded;
import com.versant.persistence.ems.Entity;
import com.versant.persistence.ems.EntityMappings;
import com.versant.persistence.ems.EntityResult;
import com.versant.persistence.ems.FieldResult;
import com.versant.persistence.ems.Id;
import com.versant.persistence.ems.JoinColumn;
import com.versant.persistence.ems.JoinTable;
import com.versant.persistence.ems.Lob;
import com.versant.persistence.ems.ManyToMany;
import com.versant.persistence.ems.ManyToOne;
import com.versant.persistence.ems.Mapping;
import com.versant.persistence.ems.NativeQuery;
import com.versant.persistence.ems.OneToMany;
import com.versant.persistence.ems.OneToOne;
import com.versant.persistence.ems.PrimaryKeyJoinColumn;
import com.versant.persistence.ems.Query;
import com.versant.persistence.ems.ResultSetMapping;
import com.versant.persistence.ems.SecondaryTable;
import com.versant.persistence.ems.SequenceGenerator;
import com.versant.persistence.ems.Table;
import com.versant.persistence.ems.TableGenerator;
import com.versant.persistence.ems.UniqueConstraint;
import com.versant.persistence.ems.Version;

/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.versant.persistence.ems package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Comment_QNAME = new QName("", "comment");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.versant.persistence.ems
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link NativeQuery }
     * 
     */
    public NativeQuery createNativeQuery() {
        return new NativeQuery();
    }

    /**
     * Create an instance of {@link Mapping }
     * 
     */
    public Mapping createMapping() {
        return new Mapping();
    }

    /**
     * Create an instance of {@link FieldResult }
     * 
     */
    public FieldResult createFieldResult() {
        return new FieldResult();
    }

    /**
     * Create an instance of {@link Entity }
     * 
     */
    public Entity createEntity() {
        return new Entity();
    }

    /**
     * Create an instance of {@link EntityResult }
     * 
     */
    public EntityResult createEntityResult() {
        return new EntityResult();
    }

    /**
     * Create an instance of {@link ManyToMany }
     * 
     */
    public ManyToMany createManyToMany() {
        return new ManyToMany();
    }

    /**
     * Create an instance of {@link Embedded }
     * 
     */
    public Embedded createEmbedded() {
        return new Embedded();
    }

    /**
     * Create an instance of {@link Embeddable }
     * 
     */
    public Embeddable createEmbeddable() {
        return new Embeddable();
    }

    /**
     * Create an instance of {@link SecondaryTable }
     * 
     */
    public SecondaryTable createSecondaryTable() {
        return new SecondaryTable();
    }

    /**
     * Create an instance of {@link JoinTable }
     * 
     */
    public JoinTable createJoinTable() {
        return new JoinTable();
    }

    /**
     * Create an instance of {@link OneToOne }
     * 
     */
    public OneToOne createOneToOne() {
        return new OneToOne();
    }

    /**
     * Create an instance of {@link Column }
     * 
     */
    public Column createColumn() {
        return new Column();
    }

    /**
     * Create an instance of {@link OneToMany }
     * 
     */
    public OneToMany createOneToMany() {
        return new OneToMany();
    }

    /**
     * Create an instance of {@link ResultSetMapping }
     * 
     */
    public ResultSetMapping createResultSetMapping() {
        return new ResultSetMapping();
    }

    /**
     * Create an instance of {@link EmbeddableSuperclass }
     * 
     */
    public EmbeddableSuperclass createEmbeddableSuperclass() {
        return new EmbeddableSuperclass();
    }

    /**
     * Create an instance of {@link UniqueConstraint }
     * 
     */
    public UniqueConstraint createUniqueConstraint() {
        return new UniqueConstraint();
    }

    /**
     * Create an instance of {@link SequenceGenerator }
     * 
     */
    public SequenceGenerator createSequenceGenerator() {
        return new SequenceGenerator();
    }

    /**
     * Create an instance of {@link Basic }
     * 
     */
    public Basic createBasic() {
        return new Basic();
    }

    /**
     * Create an instance of {@link ManyToOne }
     * 
     */
    public ManyToOne createManyToOne() {
        return new ManyToOne();
    }

    /**
     * Create an instance of {@link TableGenerator }
     * 
     */
    public TableGenerator createTableGenerator() {
        return new TableGenerator();
    }

    /**
     * Create an instance of {@link Lob }
     * 
     */
    public Lob createLob() {
        return new Lob();
    }

    /**
     * Create an instance of {@link Version }
     * 
     */
    public Version createVersion() {
        return new Version();
    }

    /**
     * Create an instance of {@link AttributeOverride }
     * 
     */
    public AttributeOverride createAttributeOverride() {
        return new AttributeOverride();
    }

    /**
     * Create an instance of {@link JoinColumn }
     * 
     */
    public JoinColumn createJoinColumn() {
        return new JoinColumn();
    }

    /**
     * Create an instance of {@link DiscriminatorColumn }
     * 
     */
    public DiscriminatorColumn createDiscriminatorColumn() {
        return new DiscriminatorColumn();
    }

    /**
     * Create an instance of {@link EntityMappings }
     * 
     */
    public EntityMappings createEntityMappings() {
        return new EntityMappings();
    }

    /**
     * Create an instance of {@link Query }
     * 
     */
    public Query createQuery() {
        return new Query();
    }

    /**
     * Create an instance of {@link PrimaryKeyJoinColumn }
     * 
     */
    public PrimaryKeyJoinColumn createPrimaryKeyJoinColumn() {
        return new PrimaryKeyJoinColumn();
    }

    /**
     * Create an instance of {@link Id }
     * 
     */
    public Id createId() {
        return new Id();
    }

    /**
     * Create an instance of {@link Table }
     * 
     */
    public Table createTable() {
        return new Table();
    }

    /**
     * Create an instance of {@link JAXBElement<String> }}
     * 
     */

    @XmlElementDecl(name = "comment", namespace = "")
    public JAXBElement<String> createComment(String value) {

        return new JAXBElement<String>(_Comment_QNAME, ((Class) String.class), null, value);
    }

}
