/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.Column;
import com.versant.persistence.ems.FetchType;
import com.versant.persistence.ems.LobType;

/**
 * Java class for lob complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="lob">
 *   <complexContent>
 *     <restriction base="xsd:anyType">
 *       <sequence>
 *         <element name="attribute" type="xsd:string"/>
 *         <element name="fetch" type="fetch-type" minOccurs="0"/>
 *         <element name="optional" type="xsd:boolean" minOccurs="0"/>
 *         <element name="lob-type" type="lob-type" minOccurs="0"/>
 *         <element name="column" type="column" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "lob")
public class Lob {

    protected String attribute;

    @XmlElement(defaultValue = "LAZY")
    protected FetchType fetch;

    @XmlElement(defaultValue = "true")
    protected Boolean optional;

    @XmlElement(defaultValue = "BLOB", name = "lob-type")
    protected LobType lobType;

    protected Column column;

    /**
     * Gets the value of the attribute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttribute() {
        return attribute;
    }

    /**
     * Sets the value of the attribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttribute(String value) {
        this.attribute = value;
    }

    /**
     * Gets the value of the fetch property.
     * 
     * @return
     *     possible object is
     *     {@link FetchType }
     *     
     */
    public FetchType getFetch() {
        return fetch;
    }

    /**
     * Sets the value of the fetch property.
     * 
     * @param value
     *     allowed object is
     *     {@link FetchType }
     *     
     */
    public void setFetch(FetchType value) {
        this.fetch = value;
    }

    /**
     * Gets the value of the optional property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOptional() {
        return optional;
    }

    /**
     * Sets the value of the optional property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOptional(Boolean value) {
        this.optional = value;
    }

    /**
     * Gets the value of the lobType property.
     * 
     * @return
     *     possible object is
     *     {@link LobType }
     *     
     */
    public LobType getLobType() {
        return lobType;
    }

    /**
     * Sets the value of the lobType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LobType }
     *     
     */
    public void setLobType(LobType value) {
        this.lobType = value;
    }

    /**
     * Gets the value of the column property.
     * 
     * @return
     *     possible object is
     *     {@link Column }
     *     
     */
    public Column getColumn() {
        return column;
    }

    /**
     * Sets the value of the column property.
     * 
     * @param value
     *     allowed object is
     *     {@link Column }
     *     
     */
    public void setColumn(Column value) {
        this.column = value;
    }

}
