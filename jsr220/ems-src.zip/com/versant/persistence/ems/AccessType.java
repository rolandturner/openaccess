/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * Java class for access-type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <simpleType name="access-type">
 *   <restriction base="xsd:NCName">
 *     <enumeration value="PROPERTY"/>
 *     <enumeration value="FIELD"/>
 *   </restriction>
 * </simpleType>
 * </pre>
 * 
 */
@XmlEnum(String.class)
public enum AccessType {

    @XmlEnumValue("FIELD")
    FIELD,
    @XmlEnumValue("PROPERTY")
    PROPERTY;

}
