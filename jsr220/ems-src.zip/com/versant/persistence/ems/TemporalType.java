/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * Java class for temporal-type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <simpleType name="temporal-type">
 *   <restriction base="xsd:NCName">
 *     <enumeration value="DATE"/>
 *     <enumeration value="TIME"/>
 *     <enumeration value="TIMESTAMP"/>
 *     <enumeration value="NONE"/>
 *   </restriction>
 * </simpleType>
 * </pre>
 * 
 */
@XmlEnum(String.class)
public enum TemporalType {

    @XmlEnumValue("DATE")
    DATE,
    @XmlEnumValue("NONE")
    NONE,
    @XmlEnumValue("TIME")
    TIME,
    @XmlEnumValue("TIMESTAMP")
    TIMESTAMP;

}
