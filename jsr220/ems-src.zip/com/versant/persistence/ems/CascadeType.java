/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * Java class for cascade-type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <simpleType name="cascade-type">
 *   <restriction base="xsd:NCName">
 *     <enumeration value="ALL"/>
 *     <enumeration value="PERSIST"/>
 *     <enumeration value="MERGE"/>
 *     <enumeration value="REMOVE"/>
 *     <enumeration value="REFRESH"/>
 *   </restriction>
 * </simpleType>
 * </pre>
 * 
 */
@XmlEnum(String.class)
public enum CascadeType {

    @XmlEnumValue("ALL")
    ALL,
    @XmlEnumValue("MERGE")
    MERGE,
    @XmlEnumValue("PERSIST")
    PERSIST,
    @XmlEnumValue("REFRESH")
    REFRESH,
    @XmlEnumValue("REMOVE")
    REMOVE;

}
