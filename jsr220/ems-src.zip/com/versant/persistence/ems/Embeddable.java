/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.Basic;
import com.versant.persistence.ems.Lob;

/**
 * Java class for embeddable complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="embeddable">
 *   <complexContent>
 *     <restriction base="xsd:anyType">
 *       <sequence>
 *         <element name="class-name" type="xsd:string"/>
 *         <element name="access" type="access-type" minOccurs="0"/>
 *         <element name="basic" type="basic" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="lob" type="lob" maxOccurs="unbounded" minOccurs="0"/>
 *         <element name="transient" type="xsd:string" maxOccurs="unbounded" minOccurs="0"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(javax.xml.bind.annotation.AccessType.FIELD)
@XmlType(name = "embeddable")
public class Embeddable {

    @XmlElement(name = "class-name")
    protected String className;

    @XmlElement(defaultValue = "PROPERTY")
    protected com.versant.persistence.ems.AccessType access;

    protected List<Basic> basic;
    protected List<Lob> lob;

    @XmlElement(name = "transient")
    protected List<String> _transient;

    /**
     * Gets the value of the className property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassName() {
        return className;
    }

    /**
     * Sets the value of the className property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassName(String value) {
        this.className = value;
    }

    /**
     * Gets the value of the access property.
     * 
     * @return
     *     possible object is
     *     {@link com.versant.persistence.ems.AccessType }
     *     
     */
    public com.versant.persistence.ems.AccessType getAccess() {
        return access;
    }

    /**
     * Sets the value of the access property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.versant.persistence.ems.AccessType }
     *     
     */
    public void setAccess(com.versant.persistence.ems.AccessType value) {
        this.access = value;
    }

    protected List<Basic> _getBasic() {
        if (basic == null) {
            basic = new ArrayList<Basic>();
        }
        return basic;
    }

    /**
     * Gets the value of the basic property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the basic property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBasic().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Basic }
     * 
     * 
     */
    public List<Basic> getBasic() {
        return this._getBasic();
    }

    protected List<Lob> _getLob() {
        if (lob == null) {
            lob = new ArrayList<Lob>();
        }
        return lob;
    }

    /**
     * Gets the value of the lob property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the lob property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLob().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Lob }
     * 
     * 
     */
    public List<Lob> getLob() {
        return this._getLob();
    }

    protected List<String> _getTransient() {
        if (_transient == null) {
            _transient = new ArrayList<String>();
        }
        return _transient;
    }

    /**
     * Gets the value of the transient property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transient property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransient().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getTransient() {
        return this._getTransient();
    }

}
