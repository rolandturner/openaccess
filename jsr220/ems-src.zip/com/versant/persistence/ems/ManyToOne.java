/**
 * @author Rick George
 * @version 1.0, 10/13/05
 */

package com.versant.persistence.ems;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.versant.persistence.ems.CascadeType;
import com.versant.persistence.ems.FetchType;
import com.versant.persistence.ems.JoinColumn;

/**
 * Java class for many-to-one complex type.
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * <complexType name="many-to-one">
 *   <complexContent>
 *     <restriction base="xsd:anyType">
 *       <sequence>
 *         <element name="attribute" type="xsd:string"/>
 *         <element name="target-entity" type="xsd:string" minOccurs="0"/>
 *         <element name="cascade" type="cascade-type" maxOccurs="3" minOccurs="0"/>
 *         <element name="fetch" type="fetch-type" minOccurs="0"/>
 *         <element name="optional" type="xsd:boolean" minOccurs="0"/>
 *         <choice>
 *           <element name="join-column" type="join-column" maxOccurs="unbounded" minOccurs="0"/>
 *         </choice>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * </pre>
 * 
 */
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "many-to-one")
public class ManyToOne {

    protected String attribute;

    @XmlElement(name = "target-entity")
    protected String targetEntity;

    protected List<CascadeType> cascade;

    @XmlElement(defaultValue = "EAGER")
    protected FetchType fetch;

    @XmlElement(defaultValue = "true")
    protected Boolean optional;

    @XmlElement(name = "join-column")
    protected List<JoinColumn> joinColumn;

    /**
     * Gets the value of the attribute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttribute() {
        return attribute;
    }

    /**
     * Sets the value of the attribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttribute(String value) {
        this.attribute = value;
    }

    /**
     * Gets the value of the targetEntity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetEntity() {
        return targetEntity;
    }

    /**
     * Sets the value of the targetEntity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetEntity(String value) {
        this.targetEntity = value;
    }

    protected List<CascadeType> _getCascade() {
        if (cascade == null) {
            cascade = new ArrayList<CascadeType>();
        }
        return cascade;
    }

    /**
     * Gets the value of the cascade property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cascade property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCascade().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CascadeType }
     * 
     * 
     */
    public List<CascadeType> getCascade() {
        return this._getCascade();
    }

    /**
     * Gets the value of the fetch property.
     * 
     * @return
     *     possible object is
     *     {@link FetchType }
     *     
     */
    public FetchType getFetch() {
        return fetch;
    }

    /**
     * Sets the value of the fetch property.
     * 
     * @param value
     *     allowed object is
     *     {@link FetchType }
     *     
     */
    public void setFetch(FetchType value) {
        this.fetch = value;
    }

    /**
     * Gets the value of the optional property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOptional() {
        return optional;
    }

    /**
     * Sets the value of the optional property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOptional(Boolean value) {
        this.optional = value;
    }

    protected List<JoinColumn> _getJoinColumn() {
        if (joinColumn == null) {
            joinColumn = new ArrayList<JoinColumn>();
        }
        return joinColumn;
    }

    /**
     * Gets the value of the joinColumn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the joinColumn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getJoinColumn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JoinColumn }
     * 
     * 
     */
    public List<JoinColumn> getJoinColumn() {
        return this._getJoinColumn();
    }

}
